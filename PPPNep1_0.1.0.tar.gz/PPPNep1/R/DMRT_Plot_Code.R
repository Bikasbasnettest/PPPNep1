#' Calculate Least Significant Difference (LSD) after DMRT test if
#' the value of LSD isnot found after DMRT test
#'
#' This function calculates the Least Significant Difference based on
#' the Mean Square Error (MSE), sample size, significance level (alpha),
#' and degrees of freedom.
#'
#' @param MSE Mean Square Error
#' @param n Sample size
#' @param alpha Significance level
#' @param df_error Degrees of freedom for the error
#' @return The calculated LSD value
#' @importFrom stats qt
#' @importFrom dplyr mutate group_by summarize
#' @importFrom ggplot2 ggplot aes geom_boxplot geom_violin theme element_text
#' @importFrom agricolae duncan.test
#' @export
#' @export
calculate_LSD <- function(MSE, n, alpha, df_error) {
  q_alpha <- qt(1 - alpha / 2, df_error)
  LSD_value <- q_alpha * sqrt(MSE / n)
  return(LSD_value)
}
library(agricolae)

#' Perform Duncan's Multiple Range Test (DMRT)
#'
#' @param data A data frame containing the data to analyze.
#' @param response_var A string specifying the name of the response variable.
#' @param group_var A string specifying the name of the grouping variable.
#' @param df_error Degrees of freedom for the error (numeric).
#' @param mse Mean Square Error (numeric).
#' @return A list containing the results of the DMRT test.
#' @export
perform_dmrt <- function(data, response_var, group_var, df_error, mse) {
  # Accessing columns using double square brackets
  result <- duncan.test(data[[response_var]], data[[group_var]], df_error, mse)
  return(result)
}
library(dplyr)
library(agricolae)

#' Summarize Means with Significance Letters from DMRT
#'
#' @param data A data frame containing the data to analyze.
#' @param response_var A string specifying the name of the response variable.
#' @param group_var A string specifying the name of the grouping variable.
#' @param dmrtcomparison An object containing DMRT results.
#' @return A data frame containing means and significance letters for each group.
#' @export
summarize_with_significance <- function(data, response_var, group_var, dmrtcomparison) {
  # Calculate mean values by group
  summary_data <- data %>%
    group_by(!!sym(group_var)) %>%
    summarize(mean_value = mean(!!sym(response_var), na.rm = TRUE), .groups = 'drop')

  # Extract significance letters
  sig.let <- dmrtcomparison$groups[order(row.names(dmrtcomparison$groups)),]

  # Check if lengths match and add significance letters
  if (length(sig.let$groups) == nrow(summary_data)) {
    summary_data <- summary_data %>%
      mutate(significance = sig.let$groups)
  } else {
    stop("Length of significance letters does not match number of groups.")
  }

  return(summary_data)
}

#################### now generation of the plto
#' Create a Combined Boxplot and Violin Plot
#'
#' @param data A data frame containing the data to visualize.
#' @param response_var A string specifying the name of the response variable (e.g., "X45PH").
#' @param group_var A string specifying the name of the grouping variable (e.g., "VAR").
#' @param lsd_value A numeric value representing the Least Significant Difference (LSD).
#' @return A ggplot object.
#' @importFrom dplyr %>% mutate group_by summarize
#' @importFrom ggplot2 ggplot aes geom_text geom_errorbar ggtitle xlab ylab
#' @importFrom ggpubr stat_compare_means
#' @importFrom rlang sym
#' @importFrom stats qt
#' @importFrom dplyr mutate group_by summarize
#' @importFrom ggplot2 ggplot aes geom_boxplot geom_violin theme element_text
#' @importFrom agricolae duncan.test
#' @importFrom ggplot2 aes_string

#' @export


create_dmrt_plot <- function(data, response_var, group_var, lsd_value) {
  response_sym <- rlang::sym(response_var)
  group_sym <- rlang::sym(group_var)

  # Create summary data for significance letters
  summary_data <- data %>%
    dplyr::group_by(!!group_sym) %>%
    dplyr::summarize(mean_yield = mean(!!response_sym, na.rm = TRUE), .groups = 'drop') %>%
    mutate(significance = NA)  # Placeholder for significance letters

  # Generate the plot
  P <- ggplot(data = data, aes_string(x = group_var, y = response_var)) +
    geom_boxplot(aes(fill = !!group_sym)) +
    geom_violin(width = 0.7) +
    geom_text(data = summary_data, aes_string(label = "significance", y = "mean_yield"), vjust = 0) +
    geom_errorbar(aes_string(ymin = paste(response_var, "- 0.6"), ymax = paste(response_var, "+ 0.6")), width = 0.2) +
    ggtitle("DMRT Mean Comparison Plot") +
    xlab(group_var) +  # Use the variable name directly
    ylab(response_var) +  # Use the variable name directly
    stat_compare_means(method = "anova") +
    stat_compare_means(label = "p.signif", method = "anova") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
    geom_text(aes_string(x = group_var[1], y = max(data[[response_var]], na.rm = TRUE) + 1,
                         label = paste("LSD =", round(lsd_value, 3))), hjust = 0, size = 4)

  return(P)
}

